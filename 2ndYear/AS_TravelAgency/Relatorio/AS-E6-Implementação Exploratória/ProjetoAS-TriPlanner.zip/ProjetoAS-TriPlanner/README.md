# ProjetoAS-TriPlanner
----------------------------
* Alexandre Martins (103552)<p>
  * Pagina Principal:<p>
    * -index.html <p>
    * -styles.css<p>
    * -main.js<p>
  * ChatBot:<p>
    * -chat.css<p>
    * -chat.js<p>
    * -responses.js<p>
----------------------------
* Bruno Gomes (103320)<p>
  * Reserva:<p>
    * -reserva.html<p>
    * -reserva.css<p>
    * -reserva.js<p>
  * Dados:<p>
    * -dados.html<p>
    * -dados.css<p>
    * -dados.js<p>
----------------------------
* Patrícia Cardoso (103243)<p>
  * Login/SignUp:<p>
    * -login.html<p>
    * -login.css<p>
  * Voo:<p>
    * -voo.html<p>
    * -voo.css<p>
----------------------------   
* Henrique Coelho (108342)<p>
  * Hotel:<p>
    * -hotel.html<p>
    * -hotel.css<p>
    * -hotel.js<p>
    * -rangeslider.js<p>
    * -rangeslider.css<p>
---------------------------- 
* Gonçalo Oliveira (108405)<p>
  * Perfil:<p>
    * -profile.html<p>
    * -styles_profile.css<p>
    * -profile.js<p>
  * Confirmação:<p>
    * -confirmation.html<p>
    * -confirmation.css<p>
----------------------------  
(alguns membros fizeram alterações do codigo dos outros conforme foi preciso (devido a dúvidas / pequenas correções)
